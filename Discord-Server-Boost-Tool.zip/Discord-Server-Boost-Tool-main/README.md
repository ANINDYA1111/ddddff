# Discord-Server-Boost-Tool
A program for mass boost server with nitro tokens

------------------------

# 🌟 Features 🌟
- Very fast threads
- Has a function to not be detected by Discord
- Support [capmonster.cloud](https://capmonster.cloud/Dashboard)

------------------------

# ⚙️ Instructions ⚙️
1) [Download](https://github.com/nyax44/Discord-Server-Boost-Tool/archive/refs/heads/main.zip)
2) Write tokens to the ``tokens.txt`` file
3) Give me a star on the project 😉
4) Open start.bat

------------------------

# ⚠️ Disclaimer ⚠️
I am not responsible for what you do. The program is for educational purposes only!

------------------------

# 🖼️ Preview 🖼️

![Preview](https://i.imgur.com/mOCF35s.png)
