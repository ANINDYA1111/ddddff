# Nitro-Redeemer
# Star this repo and follow if you actually want to see more good tools posted here!

Boost Nations nitro redeemer that I made for them, fixed.

This was made 3-4 months ago so don't expect the code to look nice, I don't code this bad trust

So I got paid to make this for boostnations, it went well I got paid they got their product until it came to updates which I had said I didn't want to do (didn't get paid for updates). So they got annoyed and blocked me blah blah blah, 4 months later I go back to it fix it and now here it is after jasu had exit scammed.

![image](https://user-images.githubusercontent.com/96021763/179582370-40ded5b2-03a7-4a8c-8b93-09c8aecf8041.png)

The only reason I released this tool is because I was sick of this browser tool taking all my proxy bandwidth and how slow it was (its faster than all the others redeemers but not fast enough for me) so I just went out made a full request nitro redeemer that can redeem in 7-11 seconds which I won't release for free, contact me to buy all the highest quality boost tools. Imagine a 14 year old kid can bypass a 95 billion dollar company (Stripe) in full requests.
